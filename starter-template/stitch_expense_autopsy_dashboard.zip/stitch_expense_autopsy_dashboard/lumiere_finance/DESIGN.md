# Design System Strategy: The Kinetic Editorial

## 1. Overview & Creative North Star
**Creative North Star: "The Kinetic Curator"**
This design system moves away from the sterile, cookie-cutter "SaaS blue" aesthetic of traditional fintech. It embraces **Soft Neobrutalism**—a style that marries the bold, high-contrast layouts of classic Brutalism with a refined, premium sensibility. We treat the interface like a high-end digital editorial: expansive, tactile, and intentionally unconventional.

The "Kinetic" aspect comes from the **physicality of the layout**. Instead of standard grids, we utilize "Bento-box" structures and overlapping "folder tab" card styles. By using extreme border radii (`xl`: 32px) and curved cutouts, we create a UI that feels sculpted rather than coded. The goal is to make every screen look like a custom-designed financial statement for the modern era.

---

## 2. Colors & Surface Philosophy
The palette is built on high-energy contrasts balanced by grounding neutrals.

### The Palette
- **Primary (`#CFFF00`):** Electric Lime. Use this for high-impact CTAs, progress indicators, and "positive" financial trends.
- **Tertiary (`#FF5A5F`):** Watermelon Red. Reserved for "Accent" moments, error states, and high-priority alerts.
- **Neutrals:** The "Soft Sage" (`#F4F5F0`) and "Matte Charcoal" (`#121416`) provide the sophisticated canvas that keeps the neobrutalist energy from feeling "cheap."

### The "No-Line" Rule
**Borders are prohibited for sectioning.** 1px solid lines create visual clutter that breaks the editorial flow. Boundaries must be defined through:
1. **Tonal Shifts:** Placing a `surface-container-low` card against a `background` fill.
2. **Negative Space:** Leveraging the spacing scale to create clear mental groupings.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the Material `surface-container` tiers to define depth:
*   **Background:** The base floor (Sage in Light, Charcoal in Dark).
*   **Surface-Container-Low:** For secondary sections or grouped content.
*   **Surface-Container-Lowest:** For the primary focus cards (White or Deep Navy).
*   **The "Folder Tab" Overlap:** Use the `xl` radius (32px) to create overlapping layers where a "tab" from one surface cuts into another, creating a physical sense of organization.

### The "Glass & Gradient" Rule
To elevate the "Premium" feel, use **Glassmorphism** for floating navigation bars or modal overlays. Apply a `surface` color at 60% opacity with a `20px` backdrop blur. 
*   **Signature Texture:** Main CTAs should not just be flat Electric Lime. Use a subtle linear gradient from `primary` (#CFFF00) to `primary_container` (#add500) at a 135-degree angle to give the button a "lit from within" glow.

---

## 3. Typography: The Manrope Scale
We use **Manrope**, a modern sans-serif with geometric foundations and organic touches, to maintain a clean yet approachable voice.

*   **Display (Editorial Impact):** Use `display-lg` and `display-md` for balance summaries and hero headlines. These should feel like magazine titles—bold and authoritative.
*   **Headline & Title (Hierarchy):** `headline-sm` is your workhorse for card titles. It provides enough weight to anchor the "Bento" boxes.
*   **Body (Utility):** `body-lg` is the default for all transactional data. Maintain generous line height (1.5x) to ensure financial figures are legible at a glance.
*   **Labels (The Micro-Data):** `label-md` and `label-sm` are used for "overlines" (tiny text above headers) and metadata. Use `on_surface_variant` to keep these secondary.

---

## 4. Elevation & Depth
In this system, elevation is **Tonal**, not structural.

### The Layering Principle
Depth is achieved by "stacking" tones. A `surface-container-highest` element feels closer to the user than a `surface-container-low` element. Avoid the "box-shadow" default.

### Ambient Shadows
If a card must "float" (e.g., a draggable credit card or a modal), use an **Ambient Shadow**:
*   **Color:** Use the `on_surface` color at 6% opacity.
*   **Blur:** `40px` to `60px`.
*   **Spread:** `-10px` to keep it soft.
*   The result should be a whisper of shadow that mimics natural room light.

### The "Ghost Border" Fallback
In high-density data views where tonal shifts aren't enough, use a **Ghost Border**:
*   `outline-variant` token at **15% opacity**.
*   This provides a hint of a container without the "heavy lifting" of a traditional border.

---

## 5. Components

### The "Folder" Card
*   **Shape:** `xl` (32px) corner radius. 
*   **The Cutout:** Use a negative border radius on one corner to create the "Physical Folder Tab" effect.
*   **Spacing:** Minimum `24px` internal padding.

### Buttons
*   **Primary:** `primary` background, `on_primary` text. `full` (9999px) radius for a "pill" look that contrasts against the bento boxes.
*   **Secondary:** `surface_container_highest` background. No border.
*   **States:** On hover, shift background to `primary_fixed_dim`.

### Input Fields
*   **Style:** Minimalist. Use `surface_container_low` as the field fill. 
*   **Focus:** A 2px `primary` (Electric Lime) "Ghost Border" (20% opacity) appears only on focus. No bottom lines.

### Chips & Tags
*   **Usage:** For transaction categories (e.g., "Groceries", "Investments").
*   **Style:** `md` (1.5rem) radius. High contrast: `primary_container` with `on_primary_container` text.

### Interactive Lists
*   **Forbidden:** Horizontal dividers (`<hr>`).
*   **Alternative:** Use `16px` of vertical white space between items. On hover, the entire row should transition to a `surface_container_high` background with an `xl` radius.

---

## 6. Do's and Don'ts

### Do
*   **DO** use extreme asymmetry. A large bento box paired with two small ones creates visual interest.
*   **DO** lean into the "Electric Lime." It is our signature. Use it for small accents (dots, sparks, icons) to lead the eye.
*   **DO** use curved cutouts. If two cards are adjacent, let one "bite" into the other slightly to emphasize the physical tab metaphor.

### Don't
*   **DON'T** use 100% black. Even in Dark Mode, use `Matte Charcoal` (#121416) to keep the "soft" in Soft Neobrutalism.
*   **DON'T** use standard 4px or 8px radiuses. It breaks the "Premium" illusion. If it’s not `xl` (32px) or `full` (pill), rethink the component.
*   **DON'T** crowd the UI. The premium feel comes from "wasted" space. If a screen feels busy, increase the padding by 1.5x.